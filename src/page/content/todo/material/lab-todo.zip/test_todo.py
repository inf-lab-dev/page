from todo import ToDo


def test_init():
    # TODO: Test the constructor of your ToDo class
    raise NotImplementedError


def test_complete():
    # TODO: Test the complete method of your ToDo class
    raise NotImplementedError


def test_update():
    # TODO: Test the update method of your ToDo class
    raise NotImplementedError

# TODO: add more tests as needed
